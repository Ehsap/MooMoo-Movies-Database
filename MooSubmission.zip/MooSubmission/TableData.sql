`--CSI2132 2016 Winter Project: Movie Recommender System
-- Team name: MooMoo Movies
-- Professor: Herna Viktor
/*Written by: Jasper Yiu        7565440 
              Avery Anggala    7664887 
              Justin Huynh      7745112
              */
         
--Task 1) Tables
CREATE TABLE Users (
    UserID      VARCHAR(20),
    password    VARCHAR(20) NOT NULL,
    lastname   VARCHAR(20) NOT NULL,
    firstname  VARCHAR(20) NOT NULL,
    email       VARCHAR(40) NOT NULL,
    city        VARCHAR(20),
    province    VARCHAR(40),
    country     VARCHAR(20) NOT NULL,
    PRIMARY KEY (UserID)
);




CREATE TABLE Profile(
    UserID      VARCHAR(20),
    agerange   VARCHAR(20) NOT NULL,
    yearborn   INTEGER NOT NULL,
    gender       CHAR(1),
    occupation  VARCHAR(20),
    deviceused VARCHAR(20),
    PRIMARY KEY (UserID),
    FOREIGN KEY (UserID) REFERENCES Users ON DELETE CASCADE
);


CREATE TABLE Topics(
    TopicID    INTEGER,
    description VARCHAR(20) NOT NULL,
    PRIMARY KEY (TopicID)     
);


CREATE TABLE Movie(
    MovieID     INTEGER,
    name        VARCHAR(40) NOT NULL,
    datereleased   DATE NOT NULL,
    PRIMARY KEY(MovieID))
);


CREATE TABLE Watches(
    UserID      VARCHAR(20) DEFAULT ‘default’,
    MovieID     INTEGER DEFAULT ‘xxx’,
    dateWatched        DATE,
    rating      INTEGER,
    PRIMARY KEY(UserID,MovieID),
    FOREIGN KEY (UserID) REFERENCES Users ON DELETE SET DEFAULT,
    FOREIGN KEY (MovieID) REFERENCES Movie ON UPDATE CASCADE ON DELETE SET DEFAULT
);


CREATE TABLE Studio (
StudioID        INTEGER,
SName        VARCHAR(20),
SCountry        VARCHAR(20),
PRIMARY KEY (StudioID) 
);


CREATE TABLE MovieTopics(
    TopicID     INTEGER,
    MovieID     INTEGER,
    language    VARCHAR(20),
    subtitles   BOOLEAN,
    country     VARCHAR(20),
    PRIMARY KEY(TopicID, MovieID), 
FOREIGN KEY (MovieID) REFERENCES Movie ON UPDATE CASCADE ON DELETE CASCADE
    );
    
CREATE TABLE Actor(
    ActorID    INTEGER,
    Alastname   VARCHAR(20),
    Afirstname  VARCHAR(20),
    Birthdate   DATE,
    PRIMARY KEY (ActorID)
);




CREATE TABLE Sponsors (
StudioID        INTEGER,
MovieID        INTEGER,
PRIMARY KEY (StudioID,MovieID),
FOREIGN KEY (StudioID) REFERENCES Studio,
FOREIGN KEY (MovieID) REFERENCES Movie ON UPDATE CASCADE
);


CREATE TABLE Director (
DirectorID        INTEGER,
DLastName        VARCHAR(20),
DFirstName        VARCHAR(20),
DCountry        VARCHAR(20),
PRIMARY KEY (DirectorID)
);


CREATE TABLE Directs (
DirectorID        INTEGER,
MovieID        INTEGER,
PRIMARY KEY (DirectorID, MovieID),
FOREIGN KEY (DirectorID) REFERENCES Director ON UPDATE CASCADE ON DELETE CASCADE,
FOREIGN KEY (MovieID) REFERENCES Movie ON UPDATE CASCADE ON DELETE CASCADE
);


CREATE TABLE Likes(
TopicID                INTEGER,
UserID                        VARCHAR(20),
PRIMARY KEY(TopicID,UserID),
FOREIGN KEY(TopicID) REFERENCES Topics ON UPDATE CASCADE ON DELETE CASCADE,
FOREIGN KEY(UserID) REFERENCES Users ON UPDATE CASCADE ON DELETE CASCADE
);


CREATE TABLE Role(
RoleID                INTEGER,
Name                VARCHAR(20),
ActorID        INTEGER,
PRIMARY KEY (RoleID, ActorID),
FOREIGN KEY (ActorID) REFERENCES Actor) ON DELETE CASCADE ON UPDATE CASCADE;


CREATE TABLE ActorPlays(
MovieID        INTEGER,
ActorID        INTEGER,
PRIMARY KEY(MovieID,ActorID),
FOREIGN KEY (MovieID) REFERENCES Movie ON UPDATE CASCADE ON DELETE CASCADE,
FOREIGN KEY (ActorID) REFERENCES Actor ON UPDATE CASCADE ON DELETE CASCADE
);


________________


-- TASK 2.) Movie Insertions


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0001,'Amy',' 2015-07-03');
--documentary,biography,music


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0002,'When Marnie Was There','2014-07-19');
--animation


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0003,'Spotlight','2015-11-25');
--history


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0004,'Inside Out','2015-06-19');
--animation,adventure


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0005,'Hot Girls Wanted','2016-05-29');
--documentary


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0006,'Mad Max: Fury Road','2015-05-15');
--action,adventure,sci-fi


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0007,'Star Wars: Episode VII - The Force Awakens','2015-12-18');
--adventure,fantasy


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0008,'Avengers: Age of Ultron','2015-05-01');
--Action, sci-fi


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0009,'The Imitation Game','2015-12-25');
--biography,war


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0010,'The Lobster','2016-05-13');
--romance


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0011,'Ant-Man','2015-07-17');
--sci-fi


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0012,'The Peanuts Movie','2015-11-06');
--adventure


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0013,'Furious 7','2015-04-03');
--crime,thriller


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0014,'The Diary of a Teenage Girl','2015-08-28');
--Drama


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0015,'Paddington','2015-01-16');
--comedy


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0016,'Miss You Already','2015-11-06');
--drama


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0017,'The Program','2016-03-18');
--biography,sport


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0018,'The Good Dinosaur','2015-11-25');
--animation


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0019,'Pitch Perfect 2','2015-05-15');
--music


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0020,'Creed','2015-11-25');
--Drama,sport


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0021,'The Big Short', '2015-12-23');
--Comedy


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0022,'The Martian','2015-10-02');
--Adventure,Sci-Fi


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0023,'Straight Outta Compton', '2015-08-14');
--Biography,History


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0024,'Steve Jobs', '2015-10-23');
--Biography


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0025, 'Sicario', '2015-10-02');
--Crime


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0026, 'Cop Car', '2015-08-07');
--Crime, Thriller


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0027,'The Revenant', '2016-01-08');
--Adventure, Drama


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0028,'Man Up', '2015-09-13');
--Comedy,Romance


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0029,'Cinderella', '2015-03-13');
--Family


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0030, 'Lost River', '2015-04-10');
--Fantasy, Mystery


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0031, 'The Final Girls', '2015-09-09');
--Horror


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0032, 'Krampus', '2015-12-04');
--Comedy, Horror


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0033, 'Stanford Prison Experiment', '2015-07-17');
--History


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0034, 'The Hateful Eight', '2015-12-30');
--Crime, Mystery


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0035, 'Jurassic World', '2015-06-12');
--action


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0036, 'Ex Machina', '2015-04-24');
--Mystery, Sci-Fi


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0037, 'Bone-Tomahawk', '2016-02-19');
--Western


INSERT INTO Movie(MovieID,name,datereleased)
VALUES(0038, 'Macbeth', '2015,12-11');
--war


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0039,'Victoria','2015-06-11');
--crime


INSERT INTO Movie (MovieID, name, datereleased)
VALUES (0040,'Knock Knock','2015-10-09');
--horror,thriller


________________




INSERT INTO Topics (TopicID, description)
VALUES (001,'Documentary');


INSERT INTO Topics (TopicID, description)
VALUES (002,'Biography');


INSERT INTO Topics (TopicID, description)
VALUES (003, 'Music');


INSERT INTO Topics (TopicID, description)
VALUES (004,'Animation');


INSERT INTO Topics (TopicID, description)
VALUES (005, 'Drama');


INSERT INTO Topics (TopicID, description)
VALUES (006,'Family');


INSERT INTO Topics (TopicID, description)
VALUES (007, 'Adventure');


INSERT INTO Topics (TopicID, description)
VALUES (008,'History');


INSERT INTO Topics (TopicID, description)
VALUES (009, 'Action');


INSERT INTO Topics (TopicID, description)
VALUES (010,'Comedy');


INSERT INTO Topics (TopicID, description)
VALUES (011, 'Fantasy');


INSERT INTO Topics (TopicID, description)
VALUES (012,'Sci-Fi');


INSERT INTO Topics (TopicID, description)
VALUES (013, 'Crime');


INSERT INTO Topics (TopicID, description)
VALUES (014,'Romance');


INSERT INTO Topics (TopicID, description)
VALUES (015,'War');


INSERT INTO Topics (TopicID, description)
VALUES (016,'Thriller');


INSERT INTO Topics (TopicID, description)
VALUES (017, 'Sport');


INSERT INTO Topics (TopicID, description)
VALUES (0018,'Western');


INSERT INTO Topics (TopicID, description)
VALUES (019, 'Horror');


INSERT INTO Topics (TopicID, description)
VALUES (020,'Mystery');




________________




INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0001,001,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0001,002,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0001,003,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0002, 004,'English',true,'Japan');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0003,008,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0004, 004,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0005,001,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0004, 007,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0007,007,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0006, 009,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0007,011,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0009,002,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0006,007,'English',true,'USA');




INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0009,015,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0011,012,'English',true,'Australia');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0006,012,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0013,013,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0008,009,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0013,016,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0015,010,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0008,012,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0017,002,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0017,017,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0010,014,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0012,007,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0019,003,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0021,010,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0014,005,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0023,002,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0023,008,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0016,005,'English',true,'France');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0025,013,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0018,004,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0020,005,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0027,007,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0020,017,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0027,005,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0029,006,'English',true,'Netherlands');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0022,007,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0031,019,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0022,012,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0033,006,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0024,002,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0026,013,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0035,009,'English',true,'Germany');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0037,018,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0026,016,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0028,010,'English',true,'Netherlands');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0039,013,'English',true,'Germany');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0040,019,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0028,014,'English',true,'USA');




INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0040,016,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0038,015,'English',true,'UK');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0030,011,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0030,020,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0036,020,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0032,010,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0036,012,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0032,019,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0034,013,'English',true,'USA');


INSERT INTO MovieTopics (MovieID,TopicID,language,subtitles,country)
VALUES (0034,020,'English',true,'USA');


________________


-- Task 3a Directors Insertions


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0001,'Kapadia','Asif', 'England');
--1


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0002,'Yonebayashi','Hiromasa', 'Japan');
--2


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0003,'McCarthy','Tom', 'USA');
--3


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0004,'Docter','Pete', 'USA');
--4


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0005,'Del-Carmen','Ronnie', 'Philippines');
--4


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0006,'Bauer','Jill', 'USA');
--5


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0007,'Gradus','Ronna', 'USA');
--5


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0008,'Miller','George', 'Australia');
--6


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0009,'Abrams','J.J', 'USA');
--7


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0010,'Whedon','Joss', 'USA');
--8


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0011,'Tyldum','Morten', 'Norway');
--9


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0012,'Lanthimos','Yorgos', 'Greece');
--10


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0013,'Reed','Peyton', 'USA');
--11


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0014,'Martino','Steve', 'USA');
--12


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0015,'Wan','James', 'Malaysia');
--13


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0016,'Heller','Marielle', 'USA');
--14


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0017,'King','Paul', 'USA');
--15


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0018,'Hardwicke','Catherine', 'USA');
--16


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0019,'Frears','Stephen', 'England');
--17


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0020,'Sohn','Peter', 'China');
--18


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0021,'Banks','Elizabeth', 'USA');
--19


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0022,'Cogler','Ryan', 'USA');
--20


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0023,'McKay','Adam', 'USA');
--21


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0024,'Scott','Ridley', 'England');
--22


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0025,'Gray','F.Gary', 'USA');
--23


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0026,'Boyle','Danny', 'England');
--24


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0027,'Villeneuve','Denis', 'Canada');
--25


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0028,'Watts','Jon', 'USA');
--26


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0029,'Inarritu','Alejandro', 'Mexico');
--27


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0030,'Palmer','Ben', 'Canada');
--28


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0031,'Branagh','Kenneth', 'Ireland');
--29


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0032,'Gosling','Ryan', 'Canada');
--30


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0033,'Strauss-Schulson','Todd', 'USA');
--31


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0034,'Dougherty','Michael', 'USA');
--32


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0035,'Tarantino','Quentin', 'USA');
--34


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0036,'Trevorrow','Colin', 'USA');
--35


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0037,'Garland','Alex', 'England');
--36


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0038,'Zahler','S.Craig', 'USA');
--37


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0039,'Kurzel','Justin', 'Australia');
--38


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0040,'Schipper','Sebastian', 'Germany');
--39


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0041,'Roth','Eli', 'USA');
--40


INSERT INTO Director (DirectorID, DLastName, DFirstName, DCountry)
VALUES (0042, 'Alvarez','Kyle', 'USA');


________________


--STUDIOS


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (001, 'Film4', 'UK');
--amy


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (002, 'Dentsu', 'Japan');
--When marnie was there, Furious 7, jurassic


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (003, 'Anonymous Content', 'USA');
--spotlight


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (004, 'Walt Disney Pictures', 'USA');
--Inside out, the good dinosaur, cinderella


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (005, 'Two To Tangle Productions', 'USA');
--Hot girls wanted


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (006, 'Warner Bros', 'USA');
--Mad max, creed


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (007, 'Lucas Film', 'USA');
--Star wars


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (008, 'Marvel Studios', 'USA');
--avengers


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (009, 'Black Bear Pictures', 'USA');
--Imitation game, knock knock


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (010, 'Film4', 'UK')
--lobster


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (011, 'Village Roadshow Pictures', 'Australia');
--mad max


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (012, 'Marvel Studios', 'USA');
--Ant man


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (013, 'Twentieth Century Fox Animation', 'USA');
--Peanuts, marshan


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (014, 'Universal Pictures', 'USA');
--Furious 7, pitch perfect 2, steve jobs, krampton, jurassic, ex machina


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (015, 'Caliber Media Company', 'USA');
--Bone-tama


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (016, 'StudioCanal', 'France');
--paddington


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (017, 'Caviar', 'USA');
--Diary of a teenage girl


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (018, 'S Films', 'UK');
--Miss you already


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (019, 'Anton Capital Entertainment', 'UK');
--The program


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (020, 'Pixar Animation Studios', 'USA');
--The good dinosaur


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (021, 'Brown Stone Productions', 'USA');
--Pitch perfect 2


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (022, 'MGM', 'USA');
--creed


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (023, 'Plan B Entertainment', 'USA');
--The big short


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (024, 'Circle of Confusion', 'USA');
--Straight outta compton


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (025,' Legendary Pictures', 'USA');
--Straight outta compton, steve jobs, Krampus, jurassic


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (026, 'Black Label Media', 'USA');
--Sicario


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (027, 'Audax Films', 'USA');
--Cop car


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (028, 'New Regency', 'USA');
--The revenent


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (029, 'Entertainment One Benelux', 'Netherlands');
--Man Up


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (030, 'Bold Films', 'USA');
--Lost river


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (031, 'Groundswell Productions', 'USA');
--The final girls 


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (032, 'Coup Detat Films', 'USA');
--Stanford prison experiment


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (033, 'Double Feature Films', 'USA');
--The hateful eight


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (034, 'See Saw Films', 'UK');
--macbeth


INSERT INTO Studio (StudioID, SName, SCountry)
VALUES (035, 'Monkey Boy', 'Germany');
--victoria
________________


--Directs Table Insertion


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0001, 0001);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0002,0002);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0003, 0003);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0004,0004);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0005, 0004);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0006,0005);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0007, 0005);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0008,0006);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0009, 0007);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0010,0008);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0011, 0009);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0012,0010);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0013, 0011);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0014,0012);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0015, 0013);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0016,0014);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0017, 0015);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0018,0016);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0019,0017);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0020,0018);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0021,0019);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0022,0020);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0023,0021);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0024,0022);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0025,0023);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0026,0024);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0027,0025);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0028,0026);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0029,0027);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0030,0028);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0031,0029);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0032,0030);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0033,0031);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0034,0032);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0035,0034);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0036,0035);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0037,0036);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0038,0037);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0039,0038);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0040,0039);


INSERT INTO Directs (DirectorID, MovieID)
VALUES (0041,0040);




INSERT INTO Directs (DirectorID, MovieID)
VALUES (0042,0033);


________________


--Sponsors Table Insertion


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (001, 0001);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (002,0002);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (002,0013);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (002,0035);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (004,0004);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (004,0018);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (004,0029);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (003, 0003);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (005, 0005);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (006,0006);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (006,0020);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (007, 0007);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (008,0008);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (009, 0009);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (009, 0040);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (010,0010);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (011, 0006);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (012,0011);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (013, 0012);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (013, 0022);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (014,0013);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (014,0019);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (014,0024);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (014,0032);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (014,0035);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (014,0036);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (015, 0037);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (016,0015);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (017, 0014);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (019, 0017);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (021, 0019);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (023, 0021);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (025, 0023);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (025, 0024);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (025, 0032);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (025, 0035);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (027, 0026);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (029, 0028);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (031, 0031);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (033, 0034);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (035, 0039);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (034, 0038);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (032, 0033);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (030, 0030);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (028, 0027);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (026, 0025);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (024, 0023);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (022, 0020);


INSERT INTO Sponsors (StudioID, MovieID)            
VALUES (020, 0018);


INSERT INTO Sponsors (StudioID, MovieID)
VALUES (018, 0016);


________________


--Users Table Insertion


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('bob12', 'bobbiful', 'Jones', 'Bob', 'bobby@gmail.com', 'Yellowknife', 'Northwest Territories', 'Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('amiez', 'applesareyummy', 'Lee', 'Amy', 'applez@gmail.com', 'Vancouver', 'British Columbia', 'Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('bigrick123','password123','Rick','Big','bigrick@gmail.com','Ottawa','Ontario','Canada');




INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('joesuo','ayllmao','Smith','Joe','joesmith@gmail.com','Los Angeles', 'California','USA');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('jackyb','applesarenotyummy','Chan','Jackson','imjackychan@yahoo.com', 'Beijing','Hebei','China');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('yungBB','moneycash','Rohn','Gudda','fadf@hotmail.com','Toronto','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('eggz','mmmm','Tama','Gude','gudesouffle@yahoo.com','Hong Kong','NA','China');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('MickeyMouse','Cheese','Mouse','Mickey','ratking@disney.com','Orlando','Florida','USA');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('Donald','quack','Duck','Deepack','duck@disney.com','Ottawa','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('creamy','pieforlife','Brulee','Creme','bruu@coconut.ca','Victoria','British Columbia','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('dreamy','awjs','Taco','Mania','jeff@taco.com','Montreal','Quebec','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('ferda','kakaJ','Yeezus','Daquan','ferda@live.ca','Ottawa','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('Justane','pieguy','Hyunk','Justor','jj@live.ca','Miami','Florida','USA');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('maplesyrup','yumyum','Johnson','Quey','moo@live.ca','Shanghai','Zhejiang','China');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('JahsperBB','double-double','You','Jahsper','qtpie@gmail.com','Vancouver','British Columbia','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('RonaldBB','bebold','Bear','Ronald','honeybear@forest.com','Ottawa','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('Yodawg','woof','Doge','Jeff','bark@dog.com','Windsor','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('shhh', 'yooshi','Jam','Jacob','joeey@gmail.com','Toronto','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('KingBob','minion','Bobbert','Kang','bubdude@live.ca','Toronto','Ontario','Canada');


INSERT INTO Users(UserID, password, lastname, firstname, email, city, province, country)
VALUES ('pumpkin','ilovetea','Huhn','Jhustin','sugarplum@gmail.com','Ottawa','Ontario','Canada');




________________


--Profile Table Insertion
--5-12 kids
--13-17 teens
--18-25 
--26-39 
--40+


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('bob12','5-12','2010','M',NULL,'Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('amiez','5-12','2010','M',NULL,'T.V');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('bigrick123','26-30',1986,'M','Lumberjack','T.V');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('joesuo','18-25',1998,'M','Student','Tablet');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('jackyb','40+',1975,'F','Fighter','Smartphone');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('yungBB','40+',1966,'F','Beer Girl','Smartphone');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('eggz','26-39',1999,'M','Politician','Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('MickeyMouse','13-17',2001,'M','Trainer','Tablet');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('Donald','13-17',2002,'M','Model','T.V');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('creamy','26-39',1990,'F','Professional Taster','T.V');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('dreamy','18-25',1992,'F','Pharmacist','Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('ferda','18-25',1994,'F','Mayor','Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('Justane','18-25',1995,'F','Student','Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('maplesyrup','18-25',1995,'M','Student','Tablet');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('JahsperBB','18-25',1995,'F','Barista','Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('RonaldBB','26-39',1990,'M','Bouncer','T.V');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('Yodawg','26-39',1978,'M','Teacher','T.V');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('shhh','5-12',2005,'M','Student','Tablet');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('KingBob','26-39',1981,'M','Wedding Planner','Laptop');


INSERT INTO Profile (UserID,agerange,yearborn,gender,occupation,deviceused)
VALUES ('pumpkin','18-25',1996,'M','Model','Laptop');






________________


--Watches Table Insertion


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('bob12',0001,'2015-12-12',4);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('bob12',0002,'2015-11-23',6);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('KingBob',0003,'2016-02-01',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('bob12',0003,'2016-02-01',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('JahsperBB',0004,'2016-03-01',7);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('dreamy',0009,'2016-01-12',5);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('Justane',0011,'2015-08-20',10);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('ferda',0011,'2015-08-20',2);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('MickeyMouse',0013,'2015-04-03',3);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('MickeyMouse',0020,'2015-11-25',NULL);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('Donald',0020,'2015-11-25',10);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('RonaldBB',0021,'2016-01-01',7);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('maplesyrup',0021,'2016-01-08',1);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('creamy',0023,'2016-02-01',1);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('shhh',0025,'2015-11-08',2);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('shhh',0022,'2016-02-02',4);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('RonaldBB',0031,'2016-01-01',7);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('Yodawg',0032,'2015-12-30',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('MickeyMouse',0032,'2015-12-30',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('Donald',0032,'2015-12-30',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('eggz',0033,'2015-12-05',5);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('creamy',0034,'2015-12-31',9);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('yungBB',0035,'2016-01-04',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('pumpkin',0035,'2015-07-01',8);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('yungBB',0036,'2016-01-04',2);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('jackyb',0037,'2016-01-05',5);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('joesuo',0038,'2016-01-12',7);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('bigrick123',0038,'2016-01-12',6);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('bigrick123',0024,'2016-01-13',2);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('Donald',0039,'2015-06-11',4);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('jackyb',0040,'2015-11-11',2);


INSERT INTO Watches(UserID,MovieID,dateWatched,rating)
VALUES('yungBB',0040,'2015-11-12',3);






________________


-- Likes Table Insertion


INSERT INTO Likes(TopicID, UserID)
VALUES(001,'bob12');


INSERT INTO Likes(TopicID, UserID)
VALUES(002,'amiez');


INSERT INTO Likes(TopicID, UserID)
VALUES(003,'bigrick123');


INSERT INTO Likes(TopicID, UserID)
VALUES(004,'bigrick123');


INSERT INTO Likes(TopicID, UserID)
VALUES(004,'joesuo');


INSERT INTO Likes(TopicID, UserID)
VALUES(005,'jackyb');


INSERT INTO Likes(TopicID, UserID)
VALUES(006,'yungBB');


INSERT INTO Likes(TopicID, UserID)
VALUES(007,'eggz');


INSERT INTO Likes(TopicID, UserID)
VALUES(008,'eggz');


INSERT INTO Likes(TopicID, UserID)
VALUES(008,'MickeyMouse');


INSERT INTO Likes(TopicID, UserID)
VALUES(009,'Donald');


INSERT INTO Likes(TopicID, UserID)
VALUES(010,'creamy');


INSERT INTO Likes(TopicID, UserID)
VALUES(011,'dreamy');


INSERT INTO Likes(TopicID, UserID)
VALUES(012,'ferda');


INSERT INTO Likes(TopicID, UserID)
VALUES(013,'Justane');


INSERT INTO Likes(TopicID, UserID)
VALUES(014,'maplesyrup');


INSERT INTO Likes(TopicID, UserID)
VALUES(014,'JahsperBB');


INSERT INTO Likes(TopicID, UserID)
VALUES(016,'RonaldBB');


INSERT INTO Likes(TopicID, UserID)
VALUES(017,'Yodawg');


INSERT INTO Likes(TopicID, UserID)
VALUES(018,'shhh');


INSERT INTO Likes(TopicID, UserID)
VALUES(019,'KingBob');


INSERT INTO Likes(TopicID, UserID)
VALUES(020,'pumpkin');
________________


--Task 3b Actors/Actresses Insertion 
--Number = Movie number


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0001,'Winehouse','Amy','1983-09-14');
--1


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0002,'Winehouse','Mitch','1950-04-23');
--1


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0003,'Ronson','Mark','1975-09-04');
--1


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0004,'Takatsuki','Sara','1981-03-13');
--2


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0005,'Arimura','Kasumi','1980-02-05');
--2


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0006,'Matsushima','Nanako','1973-10-13');
--2


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0007,'Ruffalo','Mark','1967-11-22');
--3


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0008,'Keaton','Michael','1951-09-05');
--3


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0009,'McAdams','Rachel','1978-11-17');
--3


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0010,'Poehler','Amy','1971-09-16');
--4


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0011,'Hader','Bill','1978-06-07');
--4


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0012,'Black','Lewis','1948-08-30');
--4


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0013,'Abraham','Farrah','1975-07-12');
--5


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0014,'Anthony','John','1971-06-01');
--5


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0015,'Bernanrd','Rachel','1968-04-23');
--5


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0016,'Hardy','Tom','1966-10-08');
--6


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0017,'Theron','Charlize','1981-11-14');
--6


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0018,'Hoult','Nicholas','1978-01-26');
--6


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0019,'Ridley','Daisy','1977-07-12');
--7


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0020,'Boyega','John',’1980-04-06');
--7


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0021,'Isaac','Oscar','1981-06-01');
--7


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0022,'Downey Jr.','Robert','1968-07-23');
--8


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0023,'Evans','Chris','1984-04-10');
--8


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0024,'Ruffalo','Mark','1979-01-14');
--8


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0025,'Cumberbatch','Benedict','1964-02-14');
--9


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0026,'Knightley','Keira','1965-03-15');
--9


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0027,'Goode','Matthew','1974-03-12');
--9


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0028,'Abrahams','Jacqueline','1979-06-30');
--10


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0029,'Ahston-Griffiths','Roger','1970-04-23');
--10


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0030,'Barden','Jessica','1971-06-01');
--10


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0031,'Rudd','Paul','1963-01-24');
--11


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0032,'Douglas','Michael','1979-08-27');
--11


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0033,'Stoll','Corey','1976-05-24');
--11


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0034,'Schnapp','Noah','1975-04-14');
--12


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0035,'Melendez','Bill','1972-07-21');
--12


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0036,'Belle-Miller','Hadley','1970-03-27');
--12


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0037,'Diesel','Vin','1976-06-23');
--13


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0038,'Walker','Paul','1974-08-21');
--13


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0039,'Johnson','Dwyane','1975-12-20');
--13


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0040,'Powley','Bel','1976-06-24');
--14


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0041,'Skarsgard','Alexander','1971-04-21');
--14


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0042,'Wilig','Kristen','1972-03-20');
--14


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0043,'Bonneville','Hugh','1965-05-21');
--15


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0044,'Hawkins','Sally','1971-07-24');
--15


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0045,'Walters','Julie','1973-04-18');
--15


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0046,'Barrymore','Drew','1971-02-25');
--16


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0047,'Collete','Toni','1981-03-27');
--16


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0048,'Cooper','Dominic','1974-04-01');
--16


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0049,'Foster','Ben','1970-06-27');
--17


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0050,'O'Dowd','Chris','1978-11-27');
--17


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0051,'Canet','Guillaume','1974-07-24');
--17


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0052,'Wright','Jeffrey','1971-09-07');
--18


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0053,'McDormand','Frances','1970-04-07');
--18


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0054,'Nipay-Padilla','Maleah','1965-08-01');
--18


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0055,'Kendrick','Anna','1979-04-19');
--19


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0056,'Wilson','Rebel','1977-01-06');
--19


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0057,'Steinfield','Hailee','1981-01-27');
--19


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0058,'B.Jordan','Michael','1983-01-08');
--20


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0059,'Stallone','Sylvester','1971-12-23');
--20


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0060,'Thompson','Tessa','1970-03-24');
--20


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0061,'Bale','Christian','1978-02-24');
--21


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0062,'Carell','Steve','1964-08-11');
--21


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0063,'Gosling','Ryan','1977-01-23');
--21


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0064,'Damon','Matt','1973-05-24');
--22


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0065,'Chastain','Jessica','1976-05-01');
--22


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0066,'Wilg','Kristen','1971-08-17');
--22


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0067,'Jackson','Oshea','1986-08-07');
--23


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0068,'Hawkins','Corey','1980-04-23');
--23


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0069,'Mitchell','Jason','1983-05-15');
--23


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0070,'Fassbender','Michael','1988-01-01');
--24


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0071,'Winslet','Kate','1970-08-07');
--24


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0072,'Rogen','Seth','1971-05-19');
--24


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0073,'Blunt','Emily','1977-06-22');
--25


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0074,'Brolin','Josh','1980-03-16');
--25


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0075,'Del-Toro','Benicio','1983-11-04');
--25


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0076,'Bacon','Kevin','1981-01-19');
--26


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0077,'Freedson-Jackson','James','1980-01-23');
--26


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0078,'Wellford','Hays','1977-02-15');
--26


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0079,'DiCaprio','Leonardo','1968-01-23');
--27


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0080,'Hardy','Tom','1971-09-17');
--27


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0081,'Poulter','Will','1969-04-18');
--27


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0082,'Bell','Lake','1965-03-21');
--28


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0083,'Pegg','Simon','1978-04-24');
--28


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0084,'Lovibond','Ophselia','1971-03-27');
--28


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0085,'James','Lily','1973-04-15');
--29


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0086,'Blanchett','Cate','1972-01-11');
--29


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0087,'Madden','Richard','1970-03-23');
--29


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0088,'Hendricks','Christina','1969-08-13');
--30


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0089,'De-Caestecker','Iain','1978-01-04');
--30


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0090,'Smith','Matt','1977-03-21');
--30


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0091,'Farmiga','Taissa','1975-04-23');
--31


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0092,'Ackerman','Malin','1976-06-08');
--31


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0093,'Devine','Adam','1970-03-14');
--31


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0094,'Scott','Adam','1973-05-21');
--32


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0095,'Collete','Toni','1978-01-12');
--32


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0096,'Koechner','David','1971-03-24');
--32


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0097,'Miller','Erza','1968-03-21');
--33


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0098,'Sheridan','Tye','1967-04-01');
--33


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0099,'Crudup','Billy','1978-03-16');
--33


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0100,'Jackson','Samuel','1978-06-08');
--34


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0101,'Russel','Kurt','1976-07-09');
--34


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0102,'Jason-Leigh','Jennifer','1977-01-12');
--34


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0103,'Pratt','Chris','1976-09-11');
--35


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0104,'Howard','Bryce','1970-01-23');
--35


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0105,'Simpkins','Ty','1971-03-27');
--35


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0106,'Vikander','Alicia','1972-05-17');
--36


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0107,'Gleeson','Domhnall','1974-06-28');
--36


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0108,'Isaac','Oscar','1971-04-02');
--36


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0109,'Russel','Kurt','1968-02-11');
--37


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0110,'Wilson','Patrick','1967-03-24');
--37


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0111,'Fox','Matthew','1973-08-27');
--37


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0112,'Fassbender','Michael','1971-06-24');
--38


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0113,'Cotillard','Marion','1973-07-22');
--38


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0114,'Madigan','Jack','1977-01-11');
--38


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0115,'Costa','Laia','1969-01-27');
--39


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0116,'Lau','Frederick','1973-05-18');
--39


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0117,'Rogowski','Franz','1972-04-21');
--39


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0118,'Reeves','Keanu','1976-06-11');
--40


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0119,'Izzo','Lorenza','1968-03-14');
--40


INSERT INTO Actor (ActorID, Alastname, Afirstname, Birthdate)
VALUES (0120,'Armas','Ana','1973-08-12');
--40


--ActorPlays Table Insertion
--movieid, actorid
INSERT INTO ActorPlays VALUES(0001,0001);
INSERT INTO ActorPlays VALUES(0001,0002);
INSERT INTO ActorPlays VALUES(0001,0003);


INSERT INTO ActorPlays VALUES(0002,0004);
INSERT INTO ActorPlays VALUES(0002,0005);
INSERT INTO ActorPlays VALUES(0002,0006);


INSERT INTO ActorPlays VALUES(0003,0007);
INSERT INTO ActorPlays VALUES(0003,0008);
INSERT INTO ActorPlays VALUES(0003,0009);


INSERT INTO ActorPlays VALUES(0004,00010);
INSERT INTO ActorPlays VALUES(0004,00011);
INSERT INTO ActorPlays VALUES(0004,00012);


INSERT INTO ActorPlays VALUES(0005,0013);
INSERT INTO ActorPlays VALUES(0005,0014);
INSERT INTO ActorPlays VALUES(0005,0015);


INSERT INTO ActorPlays VALUES(0006,0016);
INSERT INTO ActorPlays VALUES(0006,0017);
INSERT INTO ActorPlays VALUES(0006,0018);


INSERT INTO ActorPlays VALUES(0007,0019);
INSERT INTO ActorPlays VALUES(0007,0020);
INSERT INTO ActorPlays VALUES(0007,0021);


INSERT INTO ActorPlays VALUES(0008,0022);
INSERT INTO ActorPlays VALUES(0008,0023);
INSERT INTO ActorPlays VALUES(0008,0024);


INSERT INTO ActorPlays VALUES(0009,0025);
INSERT INTO ActorPlays VALUES(0009,0026);
INSERT INTO ActorPlays VALUES(0009,0027);


INSERT INTO ActorPlays VALUES(0010,0028);
INSERT INTO ActorPlays VALUES(0010,0029);
INSERT INTO ActorPlays VALUES(0010,0030);


INSERT INTO ActorPlays VALUES(0011,0031);
INSERT INTO ActorPlays VALUES(0011,0032);
INSERT INTO ActorPlays VALUES(0011,0033);


INSERT INTO ActorPlays VALUES(0012,0034);
INSERT INTO ActorPlays VALUES(0012,0035);
INSERT INTO ActorPlays VALUES(0012,0036);


INSERT INTO ActorPlays VALUES(0013,0037);
INSERT INTO ActorPlays VALUES(0013,0038);
INSERT INTO ActorPlays VALUES(0013,0039);


INSERT INTO ActorPlays VALUES(0014,0040);
INSERT INTO ActorPlays VALUES(0014,0041);
INSERT INTO ActorPlays VALUES(0014,0042);


INSERT INTO ActorPlays VALUES(0015,0043);
INSERT INTO ActorPlays VALUES(0015,0044);
INSERT INTO ActorPlays VALUES(0015,0045);


INSERT INTO ActorPlays VALUES(0016,0046);
INSERT INTO ActorPlays VALUES(0016,0047);
INSERT INTO ActorPlays VALUES(0016,0048);


INSERT INTO ActorPlays VALUES(0017,0049);
INSERT INTO ActorPlays VALUES(0017,0050);
INSERT INTO ActorPlays VALUES(0017,0051);


INSERT INTO ActorPlays VALUES(0018,0052);
INSERT INTO ActorPlays VALUES(0018,0053);
INSERT INTO ActorPlays VALUES(0018,0054);


INSERT INTO ActorPlays VALUES(0019,0055);
INSERT INTO ActorPlays VALUES(0019,0056);
INSERT INTO ActorPlays VALUES(0019,0057);


INSERT INTO ActorPlays VALUES(0020,0058);
INSERT INTO ActorPlays VALUES(0020,0059);
INSERT INTO ActorPlays VALUES(0020,0060);


INSERT INTO ActorPlays VALUES(0021,0061);
INSERT INTO ActorPlays VALUES(0021,0062);
INSERT INTO ActorPlays VALUES(0021,0063);


INSERT INTO ActorPlays VALUES(0022,0064);
INSERT INTO ActorPlays VALUES(0022,0065);
INSERT INTO ActorPlays VALUES(0022,0066);


INSERT INTO ActorPlays VALUES(0023,0067);
INSERT INTO ActorPlays VALUES(0023,0068);
INSERT INTO ActorPlays VALUES(0023,0069);


INSERT INTO ActorPlays VALUES(0024,0070);
INSERT INTO ActorPlays VALUES(0024,0071);
INSERT INTO ActorPlays VALUES(0024,0072);


INSERT INTO ActorPlays VALUES(0025,0073);
INSERT INTO ActorPlays VALUES(0025,0074);
INSERT INTO ActorPlays VALUES(0025,0075);


INSERT INTO ActorPlays VALUES(0026,0076);
INSERT INTO ActorPlays VALUES(0026,0077);
INSERT INTO ActorPlays VALUES(0026,0078);


INSERT INTO ActorPlays VALUES(0027,0079);
INSERT INTO ActorPlays VALUES(0027,0080);
INSERT INTO ActorPlays VALUES(0027,0081);


INSERT INTO ActorPlays VALUES(0028,0082);
INSERT INTO ActorPlays VALUES(0028,0083);
INSERT INTO ActorPlays VALUES(0028,0084);


INSERT INTO ActorPlays VALUES(0029,0085);
INSERT INTO ActorPlays VALUES(0029,0086);
INSERT INTO ActorPlays VALUES(0029,0087);


INSERT INTO ActorPlays VALUES(0030,0088);
INSERT INTO ActorPlays VALUES(0030,0089);
INSERT INTO ActorPlays VALUES(0030,0090);


INSERT INTO ActorPlays VALUES(0031,0091);
INSERT INTO ActorPlays VALUES(0031,0092);
INSERT INTO ActorPlays VALUES(0031,0093);


INSERT INTO ActorPlays VALUES(0032,0094);
INSERT INTO ActorPlays VALUES(0032,0095);
INSERT INTO ActorPlays VALUES(0032,0096);


INSERT INTO ActorPlays VALUES(0033,0097);
INSERT INTO ActorPlays VALUES(0033,0098);
INSERT INTO ActorPlays VALUES(0033,0099);


INSERT INTO ActorPlays VALUES(0034,0100);
INSERT INTO ActorPlays VALUES(0034,0101);
INSERT INTO ActorPlays VALUES(0034,0102);


INSERT INTO ActorPlays VALUES(0035,0103);
INSERT INTO ActorPlays VALUES(0035,0104);
INSERT INTO ActorPlays VALUES(0035,0105);


INSERT INTO ActorPlays VALUES(0036,0106);
INSERT INTO ActorPlays VALUES(0036,0107);
INSERT INTO ActorPlays VALUES(0036,0108);


INSERT INTO ActorPlays VALUES(0037,0109);
INSERT INTO ActorPlays VALUES(0037,0110);
INSERT INTO ActorPlays VALUES(0037,0111);


INSERT INTO ActorPlays VALUES(0038,0112);
INSERT INTO ActorPlays VALUES(0038,0113);
INSERT INTO ActorPlays VALUES(0038,0114);


INSERT INTO ActorPlays VALUES(0039,0115);
INSERT INTO ActorPlays VALUES(0039,0116);
INSERT INTO ActorPlays VALUES(0039,0117);


INSERT INTO ActorPlays VALUES(0040,0118);
INSERT INTO ActorPlays VALUES(0040,0119);
INSERT INTO ActorPlays VALUES(0040,0120);





-- Roles Table Insertion

INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0001,'Main',0001);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0002,'Main',0002);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0003,'Main',0003);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0004,'Main',0004);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0005,'Main',0005);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0006,'Main',0006);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0007,'Main',0007);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0008,'Main',0008);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0009,'Main',0009);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0010,'Main',0010);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0011,'Main',0011);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0012,'Main',0012);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0013,'Main',0013);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0014,'Main',0014);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0015,'Main',0015);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0016,'Main',0016);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0017,'Main',0017);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0018,'Main',0018);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0019,'Main',0019);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0020,'Main',0020);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0021,'Main',0021);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0022,'Main',0022);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0023,'Main',0023);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0024,'Main',0024);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0025,'Main',0025);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0026,'Main',0026);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0027,'Main',0027);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0028,'Main',0028);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0029,'Main',0029);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0030,'Main',0030);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0031,'Main',0031);


INSERT INTO Rol3e (RoleID, Name, ActorID)
VALUES(0032,'Main',0032);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0033,'Main',0033);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0034,'Main',0034);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0035,'Main',0035);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0036,'Main',0036);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0037,'Main',0037);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0038,'Main',0038);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0039,'Main',0039);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0040,'Main',0040);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0041,'Main',0041);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0042,'Main',0042);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0043,'Main',0043);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0044,'Main',0044);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0045,'Main',0045);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0046,'Main',0046);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0047,'Main',0047);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0048,'Main',0048);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0049,'Main',0049);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0050,'Main',0050);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0051,'Main',0051);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0052,'Main',0052);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0053,'Main',0053);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0054,'Main',0054);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0055,'Main',0055);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0056,'Main',0056);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0057,'Main',0057);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0058,'Main',0058);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0059,'Main',0059);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0060,'Main',0060);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0061,'Supporting',0061);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0062,'Supporting',0062);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0063,'Supporting',0063);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0064,'Supporting',0064);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0065,'Supporting',0065);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0066,'Supporting',0066);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0067,'Supporting',0067);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0068,'Supporting',0068);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0069,'Supporting',0069);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0070,'Supporting',0070);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0071,'Supporting',0071);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0072,'Supporting',0072);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0073,'Supporting',0073);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0074,'Supporting',0074);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0075,'Supporting',0075);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0076,'Supporting',0076);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0077,'Supporting',0077);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0078,'Supporting',0078);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0079,'Supporting',0079);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0080,'Supporting',0080);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0081,'Supporting',0081);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0082,'Supporting',0082);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0083,'Supporting',0083);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0084,'Supporting',0084);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0085,'Supporting',0085);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0086,'Supporting',0086);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0087,'Supporting',0087);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0088,'Supporting',0088);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0089,'Supporting',0089);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0090,'Supporting',0090);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0091,'Supporting',0091);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0092,'Supporting',0092);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0093,'Supporting',0093);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0094,'Supporting',0094);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0095,'Supporting',0095);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0096,'Supporting',0096);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0097,'Supporting',0097);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0098,'Supporting',0098);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0099,'Supporting',0099);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0100,'Supporting',0100);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0101,'Supporting',0101);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0102,'Supporting',0102);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0103,'Supporting',0103);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0104,'Supporting',0104);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0105,'Supporting',0105);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0106,'Supporting',0106);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0107,'Supporting',0107);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0108,'Supporting',0108);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0109,'Supporting',0109);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0110,'Supporting',0110);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0111,'Supporting',0111);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0112,'Supporting',0112);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0113,'Supporting',0113);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0114,'Supporting',0114);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0115,'Supporting',0115);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0116,'Supporting',0116);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0117,'Supporting',0117);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0118,'Supporting',0118);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0119,'Supporting',0119);


INSERT INTO Role (RoleID, Name, ActorID)
VALUES(0120,'Supporting',0120);















   





